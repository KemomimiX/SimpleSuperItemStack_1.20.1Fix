/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.level.biome;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.core.Holder;
import net.minecraft.sounds.Music;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.*;
import net.minecraft.world.level.biome.BiomeSpecialEffects.GrassColorModifier;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public final class BiomeHooks {
    public static BiomeProperties getBiomeProperties(Biome biome) {
        return new BiomeWrapped(biome);
    }
    
    public static class BiomeWrapped implements BiomeProperties {
        protected final Biome biome;
        protected final ClimateProperties climateProperties;
        protected final EffectsProperties effectsProperties;
        protected final GenerationProperties generationProperties;
        protected final SpawnProperties spawnProperties;
        
        public BiomeWrapped(Biome biome) {
            this(biome,
                    new ClimateWrapped(biome),
                    new EffectsWrapped(biome),
                    new GenerationSettingsWrapped(biome),
                    new SpawnSettingsWrapped(biome));
        }
        
        public BiomeWrapped(Biome biome,
                            ClimateProperties climateProperties,
                            EffectsProperties effectsProperties,
                            GenerationProperties generationProperties,
                            SpawnProperties spawnProperties) {
            this.biome = biome;
            this.climateProperties = climateProperties;
            this.effectsProperties = effectsProperties;
            this.generationProperties = generationProperties;
            this.spawnProperties = spawnProperties;
        }
        
        @Override
        public ClimateProperties getClimateProperties() {
            return climateProperties;
        }
        
        @Override
        public EffectsProperties getEffectsProperties() {
            return effectsProperties;
        }
        
        @Override
        public GenerationProperties getGenerationProperties() {
            return generationProperties;
        }
        
        @Override
        public SpawnProperties getSpawnProperties() {
            return spawnProperties;
        }
    }
    
    public static class MutableBiomeWrapped extends BiomeWrapped implements BiomeProperties.Mutable {
        public MutableBiomeWrapped(Biome biome,
                                   GenerationProperties.Mutable generationProperties,
                                   SpawnProperties.Mutable spawnProperties) {
            this(biome,
                    new ClimateWrapped(extractClimateSettings(biome)),
                    new EffectsWrapped(biome.m_47557_()),
                    generationProperties,
                    spawnProperties);
        }
        
        public MutableBiomeWrapped(Biome biome,
                                   ClimateProperties.Mutable climateProperties,
                                   EffectsProperties.Mutable effectsProperties,
                                   GenerationProperties.Mutable generationProperties,
                                   SpawnProperties.Mutable spawnProperties) {
            super(biome,
                    climateProperties,
                    effectsProperties,
                    generationProperties,
                    spawnProperties);
        }
        
        @Override
        public ClimateProperties.Mutable getClimateProperties() {
            return (ClimateProperties.Mutable) super.getClimateProperties();
        }
        
        @Override
        public EffectsProperties.Mutable getEffectsProperties() {
            return (EffectsProperties.Mutable) super.getEffectsProperties();
        }
        
        @Override
        public GenerationProperties.Mutable getGenerationProperties() {
            return (GenerationProperties.Mutable) super.getGenerationProperties();
        }
        
        @Override
        public SpawnProperties.Mutable getSpawnProperties() {
            return (SpawnProperties.Mutable) super.getSpawnProperties();
        }
    }
    
    @ExpectPlatform
    private static Biome.ClimateSettings extractClimateSettings(Biome biome) {
        return null;
    }
    
    public static class ClimateWrapped implements ClimateProperties.Mutable {
        
        protected final Biome.ClimateSettings climateSettings;
        
        public ClimateWrapped(Biome biome) {
            this(extractClimateSettings(biome));
        }
        
        public ClimateWrapped(Biome.ClimateSettings climateSettings) {
            this.climateSettings = climateSettings;
        }
        
        @Override
        public Mutable setHasPrecipitation(boolean hasPrecipitation) {
            climateSettings.f_263819_ = hasPrecipitation;
            return this;
        }
        
        @Override
        public Mutable setTemperature(float temperature) {
            climateSettings.f_47681_ = temperature;
            return this;
        }
        
        @Override
        public Mutable setTemperatureModifier(Biome.TemperatureModifier temperatureModifier) {
            climateSettings.f_47682_ = temperatureModifier;
            return this;
        }
        
        @Override
        public Mutable setDownfall(float downfall) {
            climateSettings.f_47683_ = downfall;
            return this;
        }
        
        @Override
        public boolean hasPrecipitation() {
            return climateSettings.f_263819_;
        }
        
        @Override
        public float getTemperature() {
            return climateSettings.f_47681_;
        }
        
        @Override
        public Biome.TemperatureModifier getTemperatureModifier() {
            return climateSettings.f_47682_;
        }
        
        @Override
        public float getDownfall() {
            return climateSettings.f_47683_;
        }
    }
    
    public static class EffectsWrapped implements EffectsProperties.Mutable {
        protected final BiomeSpecialEffects effects;
        
        public EffectsWrapped(Biome biome) {
            this(biome.m_47557_());
        }
        
        public EffectsWrapped(BiomeSpecialEffects effects) {
            this.effects = effects;
        }
        
        @Override
        public EffectsProperties.Mutable setFogColor(int color) {
            effects.f_47927_ = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setWaterColor(int color) {
            effects.f_47928_ = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setWaterFogColor(int color) {
            effects.f_47929_ = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setSkyColor(int color) {
            effects.f_47930_ = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setFoliageColorOverride(@Nullable Integer colorOverride) {
            effects.f_47931_ = Optional.ofNullable(colorOverride);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setGrassColorOverride(@Nullable Integer colorOverride) {
            effects.f_47932_ = Optional.ofNullable(colorOverride);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setGrassColorModifier(GrassColorModifier modifier) {
            effects.f_47933_ = modifier;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientParticle(@Nullable AmbientParticleSettings settings) {
            effects.f_47934_ = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientLoopSound(@Nullable Holder<SoundEvent> sound) {
            effects.f_47935_ = Optional.ofNullable(sound);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientMoodSound(@Nullable AmbientMoodSettings settings) {
            effects.f_47936_ = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientAdditionsSound(@Nullable AmbientAdditionsSettings settings) {
            effects.f_47937_ = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setBackgroundMusic(@Nullable Music music) {
            effects.f_47938_ = Optional.ofNullable(music);
            return this;
        }
        
        @Override
        public int getFogColor() {
            return effects.f_47927_;
        }
        
        @Override
        public int getWaterColor() {
            return effects.f_47928_;
        }
        
        @Override
        public int getWaterFogColor() {
            return effects.f_47929_;
        }
        
        @Override
        public int getSkyColor() {
            return effects.f_47930_;
        }
        
        @Override
        public OptionalInt getFoliageColorOverride() {
            return effects.f_47931_.map(OptionalInt::of).orElseGet(OptionalInt::empty);
        }
        
        @Override
        public OptionalInt getGrassColorOverride() {
            return effects.f_47932_.map(OptionalInt::of).orElseGet(OptionalInt::empty);
        }
        
        @Override
        public GrassColorModifier getGrassColorModifier() {
            return effects.f_47933_;
        }
        
        @Override
        public Optional<AmbientParticleSettings> getAmbientParticle() {
            return effects.f_47934_;
        }
        
        @Override
        public Optional<Holder<SoundEvent>> getAmbientLoopSound() {
            return effects.f_47935_;
        }
        
        @Override
        public Optional<AmbientMoodSettings> getAmbientMoodSound() {
            return effects.f_47936_;
        }
        
        @Override
        public Optional<AmbientAdditionsSettings> getAmbientAdditionsSound() {
            return effects.f_47937_;
        }
        
        @Override
        public Optional<Music> getBackgroundMusic() {
            return effects.f_47938_;
        }
    }
    
    public static class GenerationSettingsWrapped implements GenerationProperties {
        protected final BiomeGenerationSettings settings;
        
        public GenerationSettingsWrapped(Biome biome) {
            this(biome.m_47536_());
        }
        
        public GenerationSettingsWrapped(BiomeGenerationSettings settings) {
            this.settings = settings;
        }
        
        @Override
        public Iterable<Holder<ConfiguredWorldCarver<?>>> getCarvers(GenerationStep.Carving carving) {
            return settings.m_204187_(carving);
        }
        
        @Override
        public Iterable<Holder<PlacedFeature>> getFeatures(GenerationStep.Decoration decoration) {
            if (decoration.ordinal() >= settings.m_47818_().size()) {
                return Collections.emptyList();
            }
            return settings.m_47818_().get(decoration.ordinal());
        }
        
        @Override
        public List<Iterable<Holder<PlacedFeature>>> getFeatures() {
            return (List<Iterable<Holder<PlacedFeature>>>) (List<?>) settings.m_47818_();
        }
    }
    
    public static class SpawnSettingsWrapped implements SpawnProperties {
        protected final MobSpawnSettings settings;
        
        public SpawnSettingsWrapped(Biome biome) {
            this(biome.m_47518_());
        }
        
        public SpawnSettingsWrapped(MobSpawnSettings settings) {
            this.settings = settings;
        }
        
        @Override
        public float getCreatureProbability() {
            return this.settings.m_48344_();
        }
        
        @Override
        public Map<MobCategory, List<MobSpawnSettings.SpawnerData>> getSpawners() {
            return null;
        }
        
        @Override
        public Map<EntityType<?>, MobSpawnSettings.MobSpawnCost> getMobSpawnCosts() {
            return null;
        }
    }
}
